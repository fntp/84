"""buke_km 原生库的 ctypes 绑定层。

``buke_km_hid64.dll`` 只支持 Windows，所以这个模块在非 Windows 上仍然可以 import，
只有真正去加载/调用时才会抛 :class:`BukeKmNotAvailable`。显式传入 ``library_path``
则跳过平台检查——测试用假的可执行库走的就是这条路。
"""

from __future__ import annotations

import ctypes
import os
import sys
import threading
from pathlib import Path
from typing import Dict, Optional

from ._errors import BukeKmError, BukeKmInitError, BukeKmNotAvailable

PACKAGE_DIR = Path(__file__).resolve().parent
DLL_NAME = "buke_km_hid64.dll"
DRIVER_DIR_NAME = "_driver"

# 与 BukeKmInterface.h 一致，全部 __cdecl。
FUNCTION_NAMES = (
    "Init",
    "SetScale",
    "SetMouseMoveTrack",
    "MouseMove",
    "MouseMoveR",
    "MouseLeftDown",
    "MouseLeftUp",
    "MouseRightDown",
    "MouseRightUp",
    "MouseMiddleDown",
    "MouseMiddleUp",
    "Mouse4Down",
    "Mouse4Up",
    "Mouse5Down",
    "Mouse5Up",
    "MouseWheelDown",
    "MouseWheelUp",
    "KeyboardDown",
    "KeyboardUp",
    "InputString",
)

# 这些是**失败时**的 Windows 错误码（GetLastError），不是 Init 的返回值。
# doc.pdf 在「返回值: 成功返回 1，失败返回 0」下面单列了一节「错误信息 Error」，
# 5/32/1072 分别对应 ERROR_ACCESS_DENIED / ERROR_SHARING_VIOLATION /
# ERROR_SERVICE_MARKED_FOR_DELETE。
INIT_ERROR_HINTS = {
    5: "权限不足。请以管理员身份运行；HID 模式还要求关闭 Windows 的「内核隔离 / 内存完整性」。",
    32: "HID 设备被占用。常见原因是罗技等厂商的后台服务，结束相关进程后重试。",
    1072: "驱动或设备状态异常，需要重启电脑后重试。",
}

INIT_FAILED_FALLBACK = (
    "Init 失败（DLL 返回 0）。常见原因：驱动没装、不是管理员、"
    "HID 模式下开着内核隔离、HID 设备被别的进程占用。"
    "先跑 `buke-km diagnose` 看驱动状态。"
)

BUTTONS = {
    "left": "Left",
    "right": "Right",
    "middle": "Middle",
    "x1": "4",
    "x2": "5",
}


LIBRARY_ENV_VAR = "BUKE_KM_LIBRARY"


def bundled_library_path() -> Path:
    """wheel 包内自带的 DLL 路径。"""
    return PACKAGE_DIR / "_bin" / DLL_NAME


def bundled_driver_dir() -> Path:
    """wheel 包内自带的驱动目录。"""
    return PACKAGE_DIR / DRIVER_DIR_NAME


def _capture_last_error() -> Optional[int]:
    """取一次 ``GetLastError``。

    只在 Windows 上有；ctypes 用 ``use_last_error=True`` 建库时会在调用前后
    各取一次，所以拿不到就是 None（DLL 没设置），不会读到别的调用的残留值。
    """
    getter = getattr(ctypes, "get_last_error", None)
    if getter is None:
        return None
    code = int(getter())
    return code or None


def _describe_init_error(code: Optional[int]) -> str:
    hint = INIT_ERROR_HINTS.get(code) if code else None
    if hint:
        return f"Init 失败（DLL 返回 0），Windows 错误码 {code}：{hint}"
    if code:
        return f"Init 失败（DLL 返回 0），Windows 错误码 {code}（未收录）。"
    return INIT_FAILED_FALLBACK


def _configure(functions: Dict[str, object]) -> None:
    """声明每个函数的参数与返回类型。

    ``Init`` 在 DLL 里是 C++ ``bool``：MSVC 只保证低字节（AL）有效，
    高 24 位是上一次运算留下的垃圾。按 ``c_int`` 读整个 EAX 就会把垃圾读进返回值
    —— 实测 Init 明明成功（AL = 1），却读出 -669062399（0xD81EEB01），
    而 0xD81EEB01 的**低字节**正是 1。所以这里必须声明成 ``c_bool``，只看低字节。
    """
    functions["Init"].argtypes = [ctypes.c_uint, ctypes.c_ubyte]
    functions["Init"].restype = ctypes.c_bool

    functions["SetScale"].argtypes = [ctypes.c_float]
    functions["SetScale"].restype = None

    functions["SetMouseMoveTrack"].argtypes = [ctypes.c_int, ctypes.c_int]
    functions["SetMouseMoveTrack"].restype = None

    # 官方文档写 MouseMove 返回值是「无」，所以它不返回任何有意义的东西；
    # 按 c_bool 读同样会读到 EAX 垃圾，别对外报一个随机真假。
    functions["MouseMove"].argtypes = [ctypes.c_int, ctypes.c_int]
    functions["MouseMove"].restype = None

    functions["MouseMoveR"].argtypes = [ctypes.c_int, ctypes.c_int]
    functions["MouseMoveR"].restype = None

    for name in FUNCTION_NAMES:
        if name.startswith("Mouse") and name.endswith(("Down", "Up")):
            if name not in ("MouseMove", "MouseMoveR"):
                functions[name].argtypes = []
                functions[name].restype = None

    for name in ("KeyboardDown", "KeyboardUp"):
        functions[name].argtypes = [ctypes.c_ushort]
        functions[name].restype = None

    functions["InputString"].argtypes = [ctypes.c_char_p]
    functions["InputString"].restype = None


class NativeLibrary:
    """一个已加载的原生库实例。"""

    def __init__(self, library_path: Optional[str] = None):
        self._lock = threading.Lock()
        if library_path is None:
            # 显式指定路径（参数或环境变量）视为调用方自己清楚在做什么，不再做平台检查。
            library_path = os.environ.get(LIBRARY_ENV_VAR) or None
        if library_path is None:
            if sys.platform != "win32":
                raise BukeKmNotAvailable(
                    "buke_km 只支持 Windows 64 位。当前系统是 "
                    f"{sys.platform}，无法加载 {DLL_NAME}。"
                )
            library_path = str(bundled_library_path())

        self.path = str(library_path)
        if not Path(self.path).exists():
            raise BukeKmError(f"找不到 buke_km 动态库：{self.path}")

        # use_last_error=True：Init 失败时才能取到官方文档里那三个错误码。
        kwargs = {"winmode": 0, "use_last_error": True}
        try:
            self._cdll = ctypes.CDLL(self.path, **kwargs)
        except OSError as exc:
            raise BukeKmError(f"加载 {self.path} 失败：{exc}") from exc

        functions: Dict[str, object] = {}
        missing = []
        for name in FUNCTION_NAMES:
            try:
                functions[name] = getattr(self._cdll, name)
            except AttributeError:
                missing.append(name)
        if missing:
            raise BukeKmError(
                f"{self.path} 缺失导出函数：{', '.join(missing)}；"
                "这个文件可能不是 buke_km 的 DLL。"
            )

        _configure(functions)
        self._functions: Optional[Dict[str, object]] = functions

    # ------------------------------------------------------------ 生命周期

    def close(self) -> None:
        """释放库句柄，可重复调用。"""
        with self._lock:
            self._functions = None
            self._cdll = None

    def _require_open(self) -> Dict[str, object]:
        functions = self._functions
        if functions is None:
            raise BukeKmError("buke_km 动态库已关闭，请重新建立实例。")
        return functions

    def available_functions(self) -> Dict[str, object]:
        return dict(self._require_open())

    # ---------------------------------------------------------------- 调用

    def init(self, pwd: int = 0, key: int = 0) -> bool:
        if not self._require_open()["Init"](pwd, key):
            code = _capture_last_error()
            raise BukeKmInitError(code, _describe_init_error(code))
        return True

    def set_scale(self, scale: float) -> None:
        self._require_open()["SetScale"](float(scale))

    def set_track(self, delay: int, step: int) -> None:
        self._require_open()["SetMouseMoveTrack"](int(delay), int(step))

    def mouse_move(self, x: int, y: int) -> None:
        self._require_open()["MouseMove"](int(x), int(y))

    def mouse_move_relative(self, rx: int, ry: int) -> None:
        self._require_open()["MouseMoveR"](int(rx), int(ry))

    def mouse_button(self, button: str, down: bool) -> None:
        try:
            suffix = BUTTONS[button.lower()]
        except (KeyError, AttributeError):
            raise BukeKmError(
                f"未知按键 {button!r}，可用值：{', '.join(sorted(BUTTONS))}"
            ) from None
        name = f"Mouse{suffix}{'Down' if down else 'Up'}"
        self._require_open()[name]()

    def mouse_wheel(self, up: bool) -> None:
        self._require_open()["MouseWheelUp" if up else "MouseWheelDown"]()

    def key_down(self, vk: int) -> None:
        self._require_open()["KeyboardDown"](int(vk))

    def key_up(self, vk: int) -> None:
        self._require_open()["KeyboardUp"](int(vk))

    def input_string(self, text: str, encoding: Optional[str] = None) -> None:
        if isinstance(text, (bytes, bytearray)):
            data = bytes(text)
        else:
            if encoding is None:
                # DLL 收的是 ANSI 字符串；中文 Windows 上就是 GBK。
                encoding = "mbcs" if sys.platform == "win32" else "utf-8"
            data = str(text).encode(encoding, errors="replace")
        self._require_open()["InputString"](data)


_lock = threading.Lock()
_default: Optional[NativeLibrary] = None


def get_library(library_path: Optional[str] = None, reset: bool = False) -> NativeLibrary:
    """进程内共享的默认库实例，懒加载。"""
    global _default
    with _lock:
        if reset and _default is not None:
            _default.close()
            _default = None
        if _default is None:
            _default = NativeLibrary(library_path)
        return _default


def close_library() -> None:
    """关闭并丢弃进程内的默认实例。"""
    global _default
    with _lock:
        if _default is not None:
            _default.close()
            _default = None
