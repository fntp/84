"""命令行入口。

用户手上一开始只有一个 wheel，所以诊断和冒烟测试都做进包里，
不需要仓库也能跑：``buke-km diagnose`` / ``buke-km smoke 800 600``。
"""

from __future__ import annotations

import argparse
import socket
import sys
import time
from typing import List, Optional, Sequence, Tuple

from . import _native
from ._api import DEFAULT_MIN_CONFIDENCE, BukeKm, move_from_json
from ._errors import BukeKmError, BukeKmInitError
from .driver import driver_status, install_driver, uninstall_driver

EXIT_OK = 0
EXIT_ERROR = 1
EXIT_NOT_MOVED = 3

PROBE_HOST = "km.bukepro.vip"


def _is_windows() -> bool:
    return sys.platform == "win32"


def _cursor_pos() -> Optional[Tuple[int, int]]:
    if not _is_windows():
        return None
    import ctypes

    class POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

    pt = POINT()
    if not ctypes.windll.user32.GetCursorPos(ctypes.byref(pt)):
        return None
    return (pt.x, pt.y)


def _set_cursor_pos(x: int, y: int) -> bool:
    if not _is_windows():
        return False
    import ctypes

    return bool(ctypes.windll.user32.SetCursorPos(int(x), int(y)))


def _check_probe_reachable(timeout: float = 5.0) -> str:
    """只是从本机探一下 443 端口通不通，属于参考信息，不是判据。

    DLL 里确实有 km.bukepro.vip 这个域名和 WS2_32 依赖，官方 README 也说免费版
    “使用时需要联网”；但实测这个端口连不上时 Init 依然能成功，所以探测失败
    不代表不能用，真正看后面 Init 的结果。
    """
    try:
        with socket.create_connection((PROBE_HOST, 443), timeout=timeout):
            return f"可连通 {PROBE_HOST}:443"
    except OSError as exc:
        return f"探测不通 {PROBE_HOST}:443（{exc}）—— 仅参考，Init 成功就说明没事"


def _print_diagnose() -> int:
    print("buke_km 诊断")
    print("-" * 48)
    print(f"平台        : {sys.platform} ({'64 位' if sys.maxsize > 2**32 else '32 位'})")
    print(f"Python      : {sys.version.split()[0]}")
    print(f"包内 DLL    : {_native.bundled_library_path()}")

    if not _is_windows():
        print()
        print("结论：buke_km 只支持 Windows 64 位，当前系统跑不了。")
        return EXIT_ERROR

    if sys.maxsize <= 2**32:
        print()
        print("结论：需要 64 位 Python（这个包只带了 buke_km_hid64.dll）。")
        return EXIT_ERROR

    status = driver_status()
    print(f"管理员      : {'是' if status['admin'] else '否'}")
    print(f"HID 驱动    : {'已安装' if status['installed'] else '未安装'}")
    if status.get("detail"):
        print(f"devcon      : {status['detail']}")
    if not status["installed"]:
        print("            → 先执行：buke-km install-driver（需管理员）")

    print(f"联网探测    : {_check_probe_reachable()}")

    print()
    print("尝试加载 DLL 并 Init ……")
    try:
        km = BukeKm()
        try:
            km.init()
        finally:
            km.close()
    except BukeKmInitError as exc:
        print(f"失败：{exc}")
        if exc.code is not None:
            print(f"Windows 错误码：{exc.code}")
        return EXIT_ERROR
    except BukeKmError as exc:
        print(f"失败：{exc}")
        return EXIT_ERROR
    print("成功：驱动就绪，可以移动鼠标了。")
    return EXIT_OK


def _print_status() -> int:
    status = driver_status()
    for key in ("platform", "supported", "installed", "admin"):
        print(f"{key:10}: {status[key]}")
    if status.get("detail"):
        print(f"detail    : {status['detail']}")
    return EXIT_OK if status["supported"] else EXIT_ERROR


def _smoke(x: int, y: int, countdown: int) -> int:
    if not _is_windows():
        print("冒烟测试只能在 Windows 上跑（当前系统不是 Windows）。")
        return EXIT_ERROR

    origin = _cursor_pos()
    print(f"当前鼠标位置：{origin}")
    print(f"目标坐标    ：({x}, {y})")
    if countdown:
        print(f"{countdown} 秒后移动鼠标，请把鼠标先放在安全位置（Ctrl+C 取消）……")
        for remaining in range(countdown, 0, -1):
            print(f"  {remaining}…")
            time.sleep(1)

    try:
        result = move_from_json({"x": x, "y": y, "confidence": 1.0})
    except BukeKmError as exc:
        print(f"失败：{exc}")
        return EXIT_ERROR

    print(f"移动结果：moved={result.moved} reason={result.reason}")
    after = _cursor_pos()
    print(f"移动后位置：{after}")

    if origin is not None:
        _set_cursor_pos(*origin)
        print(f"已把鼠标放回原位：{origin}")

    return EXIT_OK if result.moved else EXIT_NOT_MOVED


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="buke-km", description="布灵键鼠（buke_km）HID 模式的封装与自检工具"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("diagnose", help="检查驱动、权限、联网情况，并试着 Init 一次")
    sub.add_parser("status", help="只看驱动状态")
    sub.add_parser("install-driver", help="安装 HID 内核驱动（需管理员）")
    sub.add_parser("uninstall-driver", help="卸载 HID 内核驱动（需管理员）")

    smoke = sub.add_parser("smoke", help="倒计时后移动到指定坐标，再移回原位")
    smoke.add_argument("x", type=int)
    smoke.add_argument("y", type=int)
    smoke.add_argument("--countdown", type=int, default=3)

    mv = sub.add_parser("move-json", help="直接喂一段坐标 JSON")
    mv.add_argument("data", help='例如 \'{"x":1250,"y":438,"confidence":0.94}\'')
    mv.add_argument("--min-confidence", type=float, default=DEFAULT_MIN_CONFIDENCE)
    mv.add_argument("--no-threshold", action="store_true", help="关闭置信度门控")

    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = _build_parser().parse_args(argv)

    try:
        if args.command == "diagnose":
            return _print_diagnose()
        if args.command == "status":
            return _print_status()
        if args.command == "install-driver":
            print(install_driver()["detail"])
            return EXIT_OK
        if args.command == "uninstall-driver":
            print(uninstall_driver()["detail"])
            return EXIT_OK
        if args.command == "smoke":
            return _smoke(args.x, args.y, args.countdown)
        if args.command == "move-json":
            threshold = None if args.no_threshold else args.min_confidence
            result = move_from_json(args.data, min_confidence=threshold)
            print(f"moved={result.moved} reason={result.reason} target={result.target}")
            return EXIT_OK if result.moved else EXIT_NOT_MOVED
    except BukeKmError as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return EXIT_ERROR

    return EXIT_ERROR


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
