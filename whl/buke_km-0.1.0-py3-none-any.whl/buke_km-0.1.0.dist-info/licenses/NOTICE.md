# 第三方组件说明

这个 wheel 里除了本仓库自己的 Python 代码，还打包了来自
[`bukepro/buke_km_lib`](https://github.com/bukepro/buke_km_lib)（布灵键鼠）的预编译二进制。
**这些二进制不是本项目的产物，也不受本项目控制。**

## 打包进来的文件

| 文件 | 大小 | SHA-256 |
| --- | --- | --- |
| `_bin/buke_km_hid64.dll` | 3,835,904 B | `5d80697a6cc02d6f7cf2e1b81cf9bb10661fe175a92e2a87e5e6a24d69f3a489` |
| `_driver/buke_km_hid_drv.sys` | 2,605,960 B | `39da97c546ba08531dd88b360a44256653b4196d275d38847d8fc5c4a977b9b7` |
| `_driver/buke_km_hid_drv.inf` | — | `44c814b01c18b238b04ed0c86399a83f8ae076c9d6c229bf2f7dd3a2c3a365c7` |
| `_driver/buke_km_hid_drv.cat` | 11,683 B | `386083c22706b49b2a4ff499334150013ebf4a973e8002d9047ac4e8512e7b77` |
| `_driver/devcon.exe` | 81,920 B | `a51e25acc489948b31b1384e1dc29518d19b421d6bc0ced90587128899275289` |
| `_driver/WdfCoInstaller01009.dll` | 1,471,800 B | `04821a735fe9c9f20e238093d92be6624bf62bb10b4bd6623682f2cfb9669db7` |
| `_driver/install.bat` | — | `9f8500d6a1f3f6d6373baa20d75430fff8f1b4e0f8210ee5f0c53e1d2d9557b6` |
| `_driver/uninstall.bat` | — | `45653704233963d79f8e3c6c7f7d6b653838056944e5c958ad59a56393c8673c` |

来源：`buke_km_lib.rar`（15.7 MB）中的 `hid/` 目录。**本包只带 64 位 HID 一套**，
不含 `normal/`（免驱模式）和 32 位版本。

## 来源与再分发

- 原仓库是**公开仓库**，但里面只有编译好的 DLL / 驱动 / 文档 / 示例，没有源码，
  也**不带 LICENSE 文件**，没有任何书面的再分发条款。
- `buke_km_hid64.dll` 经过加壳混淆（节区名被打乱、含 VMProtect 特征段），
  **无法审计其行为**；本文档对它「做了什么」的描述全部来自导出表、导入表和官方文档，
  不是对代码的审阅结论。
- 原仓库 README 写「这是免费版本，使用时需要联网」，DLL 里也确实有 `km.bukepro.vip`
  这个域名并链接了 `WS2_32`，运行时会与该服务器通信。至于联网是用于校验、统计还是别的，
  加壳后的二进制看不出，**不要臆测**。
- 因此：**把它打进 wheel 只适合自用**。对外分发需要先去
  [bukepro/buke_km_lib](https://github.com/bukepro/buke_km_lib) 问问作者。

## 驱动签名

`buke_km_hid_drv.cat` 的签名主体是 `Microsoft Windows Hardware Compatibility Publisher`
（WHQL），所以正常情况下安装不需要开启测试签名模式，也不需要 `bcdedit /set testsigning on`。

## 杀毒软件

加壳 DLL + 内核驱动 + 模拟输入，这三样凑一起，杀软和 EDR 大概率直接拦。
这是这类工具的固有特征，不是本项目引入的缺陷；需要在你的环境里自行加白名单，
并确认这么做符合你所在环境的安全策略。
