"""对外 API：把「一串坐标 JSON」变成「鼠标挪过去」。"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Any, Optional, Tuple

from ._native import NativeLibrary
from ._targets import DEFAULT_CONFIDENCE_KEY, resolve

DEFAULT_MIN_CONFIDENCE = 0.6


@dataclass(frozen=True)
class MoveResult:
    """一次移动尝试的结果。"""

    moved: bool
    target: Optional[dict]
    reason: str

    def __bool__(self) -> bool:
        return self.moved


class BukeKm:
    """对 buke_km 的 20 个原生函数做薄封装。

    默认在第一次调用前自动 ``Init``；调用方需要自己控制顺序时用 ``auto_init=False``。
    """

    def __init__(
        self,
        library_path: Optional[str] = None,
        auto_init: bool = True,
        pwd: int = 0,
        key: int = 0,
    ):
        self._lib = NativeLibrary(library_path)
        self._auto_init = auto_init
        self._pwd = pwd
        self._key = key
        self._inited = False
        self._closed = False
        # Init 延迟到第一次真正要动作时：这样 configure() 之类的调用
        # 不会因为环境没就绪而失败。

    # ------------------------------------------------------------ 生命周期

    @property
    def closed(self) -> bool:
        return self._closed

    def _ensure_open(self) -> None:
        if self._closed:
            raise RuntimeError("这个 BukeKm 实例已关闭")

    def _ensure_init(self) -> None:
        self._ensure_open()
        if self._inited or not self._auto_init:
            return
        self.init(self._pwd, self._key)

    def init(self, pwd: int = 0, key: int = 0) -> bool:
        """显式初始化。返回码不是 1 时抛 :class:`BukeKmInitError`。"""
        self._ensure_open()
        ok = self._lib.init(pwd, key)
        self._inited = True
        return ok

    def close(self) -> None:
        self._closed = True
        self._inited = False
        self._lib.close()

    # ---------------------------------------------------------------- 动作

    def set_scale(self, scale: float) -> None:
        self._ensure_open()
        self._lib.set_scale(scale)

    def set_track(self, delay: int, step: int) -> None:
        self._ensure_open()
        self._lib.set_track(delay, step)

    def move(self, x: int, y: int) -> bool:
        self._ensure_init()
        return self._lib.mouse_move(x, y)

    def move_relative(self, rx: int, ry: int) -> None:
        self._ensure_init()
        self._lib.mouse_move_relative(rx, ry)

    def move_from_json(
        self,
        data: Any,
        min_confidence: Optional[float] = DEFAULT_MIN_CONFIDENCE,
        confidence_key: str = DEFAULT_CONFIDENCE_KEY,
    ) -> MoveResult:
        return _resolve_and_move(
            lambda x, y: self.move(x, y), data, min_confidence, confidence_key
        )

    def button(self, name: str, down: bool = True) -> None:
        self._ensure_init()
        self._lib.mouse_button(name, down)

    def click(self, x: int, y: int, button: str = "left", hold_ms: int = 0) -> None:
        self.move(x, y)
        if hold_ms:
            import time

            time.sleep(hold_ms / 1000.0)
        self.button(button, True)
        self.button(button, False)

    def wheel(self, up: bool = True) -> None:
        self._ensure_init()
        self._lib.mouse_wheel(up)

    def key_down(self, vk: int) -> None:
        self._ensure_init()
        self._lib.key_down(vk)

    def key_up(self, vk: int) -> None:
        self._ensure_init()
        self._lib.key_up(vk)

    def type_text(self, text: str, encoding: Optional[str] = None) -> None:
        self._ensure_init()
        self._lib.input_string(text, encoding)


def _resolve_and_move(move, data, min_confidence, confidence_key) -> MoveResult:
    target, reason = resolve(data, min_confidence, confidence_key)
    if reason != "ok":
        return MoveResult(
            moved=False,
            target=target.as_dict() if target is not None else None,
            reason=reason,
        )
    move(target.x, target.y)
    return MoveResult(moved=True, target=target.as_dict(), reason="ok")


# ------------------------------------------------------------- 模块级默认实例

_default_lock = threading.Lock()
_default: Optional[BukeKm] = None


def _get_default() -> BukeKm:
    global _default
    with _default_lock:
        if _default is None or _default.closed:
            # 构造失败时异常会在赋值前抛出，_default 保持为 None，下次调用可重试。
            _default = BukeKm()
        return _default


def move_from_json(
    data: Any,
    min_confidence: Optional[float] = DEFAULT_MIN_CONFIDENCE,
    confidence_key: str = DEFAULT_CONFIDENCE_KEY,
) -> MoveResult:
    """解析坐标 JSON 并把鼠标移过去。

    ``data`` 可以是 JSON 字符串/字节、``dict``，或 ``list[dict]``（多目标取置信度最高者）。
    最高分低于 ``min_confidence`` 时不移动鼠标，返回 ``reason="low_confidence"``；
    空数组（这一帧没目标）返回 ``moved=False, target=None, reason="no_targets"``，
    不抛异常；``min_confidence=None`` 关闭阈值门控。
    """
    return _resolve_and_move(
        lambda x, y: _get_default().move(x, y), data, min_confidence, confidence_key
    )


def configure(scale: Optional[float] = None, track: Optional[Tuple[int, int]] = None) -> None:
    """调整全局缩放与移动轨迹。不需要驱动就绪，可提前调用。"""
    km = _get_default()
    if scale is not None:
        km.set_scale(scale)
    if track is not None:
        delay, step = track
        km.set_track(delay, step)


def close() -> None:
    """关闭并丢弃模块级默认实例，可重复调用。"""
    global _default
    with _default_lock:
        if _default is not None:
            _default.close()
            _default = None
