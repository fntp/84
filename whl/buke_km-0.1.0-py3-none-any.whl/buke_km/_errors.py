"""buke_km 的异常类型。"""


class BukeKmError(Exception):
    """本包所有异常的基类。"""


class BukeKmNotAvailable(BukeKmError):
    """当前平台或环境无法使用 buke_km（例如在非 Windows 上调用）。"""


class BukeKmInitError(BukeKmError):
    """DLL 已加载但 ``Init`` 失败——通常是驱动没装、权限不足，或设备被别的软件占用。

    ``.code`` 是 ``Init`` 的原始返回码（5 权限/内核隔离、32 设备被占用、1072 需重启）。
    """

    def __init__(self, code: int, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


class TargetFormatError(BukeKmError, ValueError):
    """传入的坐标 JSON 不符合预期结构。"""
