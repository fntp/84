"""HID 内核驱动的安装 / 卸载 / 状态查询。

HID 模式必须装内核驱动才能用；驱动包（``.sys`` / ``.inf`` / WHQL 签名的 ``.cat`` /
``devcon.exe``）随 wheel 一起分发，所以用户不需要另外找 buke_km 的原始压缩包。
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Dict, List

from ._errors import BukeKmError, BukeKmNotAvailable
from ._native import bundled_driver_dir

HARDWARE_ID = r"buke\km_hid"
HID_ID_PATTERN = r"HID\km_hid*"

DLL_NAME = "buke_km_hid64.dll"
REQUIRED_FILES = (
    "buke_km_hid_drv.sys",
    "buke_km_hid_drv.inf",
    "buke_km_hid_drv.cat",
    "devcon.exe",
)


def _require_windows() -> None:
    if sys.platform != "win32":
        raise BukeKmNotAvailable(
            "buke_km 的 HID 驱动只支持 Windows 64 位；当前系统是 "
            f"{sys.platform}。"
        )


def _is_admin() -> bool:
    if sys.platform != "win32":
        return False
    try:
        import ctypes

        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def devcon_path() -> Path:
    return bundled_driver_dir() / "devcon.exe"


def driver_inf_path() -> Path:
    return bundled_driver_dir() / "buke_km_hid_drv.inf"


def _run_devcon(args: List[str], timeout: int = 180) -> subprocess.CompletedProcess:
    """跑包内的 devcon.exe。单独抽出来是为了能在非 Windows 上打桩测试。"""
    exe = devcon_path()
    if not exe.exists():
        raise BukeKmError(f"包内缺少 {exe}，无法操作驱动。")
    return subprocess.run(
        [str(exe)] + args,
        cwd=str(bundled_driver_dir()),
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _missing_driver_files() -> List[str]:
    return [name for name in REQUIRED_FILES if not (bundled_driver_dir() / name).exists()]


def driver_status() -> Dict[str, object]:
    """查询驱动与运行环境状态。"""
    if sys.platform != "win32":
        return {
            "platform": sys.platform,
            "supported": False,
            "installed": False,
            "admin": False,
            "detail": "HID 驱动只支持 Windows 64 位",
        }

    admin = _is_admin()
    proc = _run_devcon(["hwids", HID_ID_PATTERN])
    output = ((proc.stdout or "") + (proc.stderr or "")).strip()
    installed = "km_hid" in output.lower() and "no matching" not in output.lower()

    detail = output
    if not installed and not admin:
        detail = f"{detail}\n（当前不是管理员，安装驱动需要管理员权限）".strip()

    return {
        "platform": sys.platform,
        "supported": True,
        "installed": installed,
        "admin": admin,
        "devcon": str(devcon_path()),
        "detail": detail,
    }


def install_driver() -> Dict[str, object]:
    """安装 HID 驱动。需要管理员权限；已经装过就直接返回。"""
    _require_windows()
    missing = _missing_driver_files()
    if missing:
        raise BukeKmError(f"包内驱动文件缺失：{', '.join(missing)}")
    if not _is_admin():
        raise BukeKmError(
            "安装 HID 驱动需要管理员权限，请以管理员身份重新运行（右键 → 以管理员身份运行）。"
        )

    if driver_status()["installed"]:
        return {"installed": True, "changed": False, "detail": "驱动已安装，无需重复操作"}

    proc = _run_devcon(["install", str(driver_inf_path()), HARDWARE_ID])
    output = ((proc.stdout or "") + (proc.stderr or "")).strip()
    if proc.returncode != 0:
        raise BukeKmError(f"devcon 安装驱动失败（退出码 {proc.returncode}）：{output}")

    return {"installed": True, "changed": True, "detail": output}


def uninstall_driver() -> Dict[str, object]:
    """卸载 HID 驱动。需要管理员权限。"""
    _require_windows()
    if not _is_admin():
        raise BukeKmError("卸载 HID 驱动需要管理员权限。")

    outputs = []
    for args in (["remove", HID_ID_PATTERN], ["remove", HARDWARE_ID]):
        proc = _run_devcon(args)
        outputs.append(((proc.stdout or "") + (proc.stderr or "")).strip())

    return {
        "installed": False,
        "changed": True,
        "detail": "\n".join(o for o in outputs if o),
    }
