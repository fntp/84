"""识别结果 JSON 的解析与挑选逻辑（纯 Python，不碰 DLL）。

DLL 本身不含任何图像识别能力，``confidence`` 完全来自调用方的识别层，
所以「什么是够格的置信度」由这里定义。
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Any, List, Optional, Tuple

from ._errors import TargetFormatError

DEFAULT_CONFIDENCE_KEY = "confidence"
DEFAULT_CONFIDENCE = 1.0


@dataclass(frozen=True)
class Target:
    """一个已归一化的目标点。"""

    x: int
    y: int
    confidence: float
    raw: Any = None

    def as_dict(self) -> dict:
        """还原成调用方给进来的形状，但 x/y/confidence 是归一化后的值。"""
        out = dict(self.raw) if isinstance(self.raw, dict) else {}
        out["x"] = self.x
        out["y"] = self.y
        out["confidence"] = self.confidence
        return out


def parse_targets(data: Any, confidence_key: str = DEFAULT_CONFIDENCE_KEY) -> List[Target]:
    """把任意受支持的输入归一化成 ``Target`` 列表。

    支持 JSON ``str`` / ``bytes``（单个对象或数组）、已解析的 ``dict``、``list[dict]``。
    空数组（``[]``）是合法的，表示这一帧没有目标，返回空列表而不是抛异常 ——
    识别层每帧都会输出结果，没抓到东西是常态，不该被打断。
    """
    payload = _loads_if_text(data)
    items = payload if isinstance(payload, list) else [payload]

    return [_parse_one(item, i, confidence_key) for i, item in enumerate(items)]


def _loads_if_text(data: Any) -> Any:
    if isinstance(data, (bytes, bytearray)):
        try:
            text = bytes(data).decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise TargetFormatError(f"无法按 UTF-8 解码坐标数据: {exc}") from exc
        return _loads(text)
    if isinstance(data, str):
        return _loads(data)
    return data


def _loads(text: str) -> Any:
    stripped = text.strip()
    if not stripped:
        raise TargetFormatError("坐标数据为空字符串")
    try:
        return json.loads(stripped)
    except json.JSONDecodeError as exc:
        raise TargetFormatError(f"坐标不是合法 JSON: {exc}") from exc


def _parse_one(item: Any, index: int, confidence_key: str) -> Target:
    where = f"第 {index + 1} 个目标"
    if not isinstance(item, dict):
        raise TargetFormatError(f"{where}不是 JSON 对象，实际是 {type(item).__name__}")

    if "x" not in item or "y" not in item:
        missing = "x" if "x" not in item else "y"
        raise TargetFormatError(f"{where}缺少字段 {missing}")

    x = _to_coord(item["x"], "x", where)
    y = _to_coord(item["y"], "y", where)
    confidence = _to_confidence(item.get(confidence_key), confidence_key, where)

    return Target(x=x, y=y, confidence=confidence, raw=item)


def _to_coord(value: Any, name: str, where: str) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TargetFormatError(f"{where}的 {name} 必须是数值，实际是 {type(value).__name__}")
    value = float(value)
    if not math.isfinite(value):
        raise TargetFormatError(f"{where}的 {name} 必须是有限数值，实际是 {value}")
    return int(math.floor(value + 0.5))


def _to_confidence(value: Any, key: str, where: str) -> float:
    if value is None:
        return DEFAULT_CONFIDENCE
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TargetFormatError(f"{where}的 {key} 必须是数值，实际是 {type(value).__name__}")
    value = float(value)
    if not math.isfinite(value):
        raise TargetFormatError(f"{where}的 {key} 必须是有限数值，实际是 {value}")
    if not 0.0 <= value <= 1.0:
        raise TargetFormatError(f"{where}的 {key} 必须落在 0~1，实际是 {value}")
    return value


def select_best(targets: List[Target]) -> Target:
    """取置信度最高的目标；并列时取先出现的那个。"""
    if not targets:
        raise TargetFormatError("目标列表为空，无法挑选")
    best = targets[0]
    for target in targets[1:]:
        if target.confidence > best.confidence:
            best = target
    return best


def resolve(
    data: Any,
    min_confidence: Optional[float] = None,
    confidence_key: str = DEFAULT_CONFIDENCE_KEY,
) -> Tuple[Optional[Target], str]:
    """解析 + 挑选 + 阈值门控。

    返回 ``(选中的目标, 原因)``，原因是 ``"ok"``、``"low_confidence"`` 或 ``"no_targets"``。
    低于阈值时目标仍然返回，由调用方决定要不要真的移动鼠标；
    没有目标时目标为 ``None``。
    """
    targets = parse_targets(data, confidence_key=confidence_key)
    if not targets:
        return None, "no_targets"
    best = select_best(targets)
    if min_confidence is not None and best.confidence < min_confidence:
        return best, "low_confidence"
    return best, "ok"
