
cd /d "%~dp0"
devcon remove HID\km_hid*
devcon remove @HID\km_hid*
devcon remove buke\km_hid
pause