
cd /d "%~dp0"
devcon.exe install buke_km_hid_drv.inf buke\km_hid
pause