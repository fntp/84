"""buke_km —— 由 JSON 识别结果直接驱动鼠标（布灵键鼠 HID 模式）。

最小用法::

    import buke_km

    res = buke_km.move_from_json('{"x": 1250, "y": 438, "confidence": 0.94}')
    res.moved   # True

多目标（自动挑置信度最高者）::

    buke_km.move_from_json('[{"x":10,"y":20,"confidence":0.31},
                            {"x":1250,"y":438,"confidence":0.94}]')
"""

from ._api import (
    DEFAULT_MIN_CONFIDENCE,
    BukeKm,
    MoveResult,
    close,
    configure,
    move_from_json,
)
from ._errors import (
    BukeKmError,
    BukeKmInitError,
    BukeKmNotAvailable,
    TargetFormatError,
)
from ._targets import Target
from .driver import driver_status, install_driver, uninstall_driver

__version__ = "0.1.0"

__all__ = [
    "BukeKm",
    "BukeKmError",
    "BukeKmInitError",
    "BukeKmNotAvailable",
    "DEFAULT_MIN_CONFIDENCE",
    "MoveResult",
    "Target",
    "TargetFormatError",
    "__version__",
    "close",
    "configure",
    "driver_status",
    "install_driver",
    "move_from_json",
    "uninstall_driver",
]
